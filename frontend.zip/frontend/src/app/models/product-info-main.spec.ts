import { ProductInfoMain } from './product-info-main';

describe('ProductInfoMain', () => {
  it('should create an instance', () => {
    expect(new ProductInfoMain()).toBeTruthy();
  });
});
