import {ProductInOrder} from "./ProductInOrder";


export class Cart {
    cartId: number;
    products: ProductInOrder[];
}
