export enum OrderStatus {
    "New",
    "Finished",
    "Cenceled"
}
