package me.shop.shopapi.api;

import org.junit.Test;

import static org.junit.Assert.*;


public class CartControllerTest {

    @Test
    public void getCart() {
    }
}
